class Teacher < ApplicationRecord
  belongs_to :office
end
